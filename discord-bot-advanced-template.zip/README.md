# Advanced Discord Bot Template

## Features
- .env support
- Cogs (extensions)
- Scalable project structure

## Setup
1. Copy `.env.example` to `.env`
2. Put your bot token in `.env`
3. pip install -r requirements.txt
4. python bot.py